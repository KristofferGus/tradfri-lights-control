from rgbxy import Converter

COLOR_CONVERTER = Converter()
PUBLISH_PREFIX = "zigbee2mqtt"
HOST = "mqtt"
OK = "OK"
